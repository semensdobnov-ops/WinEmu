package com.winemu

import android.content.Context
import java.io.File
import java.io.RandomAccessFile

data class VmConfig(
    val name: String = "Windows",
    val ramMb: Int = 4096,
    val cpus: Int = 4,
    val diskGb: Int = 64,
    val isoPath: String = "/sdcard/Download/windows.iso"
)

object Qemu {
    private var proc: Process? = null

    fun isRunning() = proc?.isAlive == true

    fun logFile(ctx: Context) = File(ctx.filesDir, "qemu.log")

    /** Собирает команду QEMU из настроек (аналог того, что делает UTM). */
    fun start(ctx: Context, c: VmConfig): String {
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        if (!bin.exists()) return "Не найден libqemu.so. Положите бинарник QEMU в app/src/main/jniLibs/arm64-v8a/ (см. README)."
        if (isRunning()) return "Уже запущено."

        val dir = File(ctx.filesDir, "vm_${c.name}").apply { mkdirs() }
        val disk = File(dir, "disk.img")
        if (!disk.exists()) RandomAccessFile(disk, "rw").use { it.setLength(c.diskGb * 1024L * 1024L * 1024L) }

        val fw = File(dir, "edk2-aarch64-code.fd")
        if (!fw.exists()) {
            try { ctx.assets.open("edk2-aarch64-code.fd").use { i -> fw.outputStream().use { i.copyTo(it) } } }
            catch (e: Exception) { return "Нет файла прошивки edk2-aarch64-code.fd в app/src/main/assets/ (см. README)." }
        }

        val args = mutableListOf(
            bin.absolutePath,
            "-machine", "virt", "-cpu", "cortex-a72",
            "-smp", c.cpus.toString(), "-m", c.ramMb.toString(),
            "-accel", "tcg,thread=multi",
            "-bios", fw.absolutePath,
            "-device", "ramfb",
            "-device", "qemu-xhci", "-device", "usb-kbd", "-device", "usb-tablet",
            "-drive", "file=${disk.absolutePath},format=raw,if=none,id=hd0",
            "-device", "nvme,drive=hd0,serial=win",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-vnc", "127.0.0.1:0"
        )
        if (File(c.isoPath).exists()) {
            args += listOf("-drive", "file=${c.isoPath},media=cdrom,if=none,id=cd0",
                "-device", "usb-storage,drive=cd0")
        }
        proc = ProcessBuilder(args)
            .directory(dir)
            .redirectErrorStream(true)
            .redirectOutput(logFile(ctx))
            .start()
        return "Запущено. Откройте VNC-клиент: 127.0.0.1:5900"
    }

    fun stop() { proc?.destroy(); proc = null }
}
