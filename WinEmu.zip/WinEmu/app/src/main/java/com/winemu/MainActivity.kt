package com.winemu

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        var name by remember { mutableStateOf("Windows") }
        var ram by remember { mutableStateOf("4096") }
        var cpus by remember { mutableStateOf("4") }
        var disk by remember { mutableStateOf("64") }
        var iso by remember { mutableStateOf("/sdcard/Download/windows.iso") }
        var status by remember { mutableStateOf("") }

        Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("WinEmu — Windows ARM через QEMU", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(name, { name = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ram, { ram = it }, label = { Text("ОЗУ, МБ") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cpus, { cpus = it }, label = { Text("Ядра CPU") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(disk, { disk = it }, label = { Text("Диск, ГБ") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(iso, { iso = it }, label = { Text("Путь к ISO") }, modifier = Modifier.fillMaxWidth())

            Button(onClick = {
                if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }) { Text("Разрешить доступ к файлам") }

            Button(onClick = {
                val cfg = VmConfig(name.trim().ifEmpty { "Windows" }, ram.toIntOrNull() ?: 4096,
                    cpus.toIntOrNull() ?: 4, disk.toIntOrNull() ?: 64, iso.trim())
                status = Qemu.start(this@MainActivity, cfg)
            }) { Text("Запустить") }

            Button(onClick = {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnc://127.0.0.1:5900"))) }
                catch (e: Exception) { status = "Установите VNC-клиент (например, bVNC или RealVNC Viewer)." }
            }) { Text("Открыть экран (VNC)") }

            OutlinedButton(onClick = { Qemu.stop(); status = "Остановлено." }) { Text("Остановить") }
            OutlinedButton(onClick = {
                status = try { Qemu.logFile(this@MainActivity).readText().takeLast(1500) } catch (e: Exception) { "Лога нет." }
            }) { Text("Показать лог QEMU") }

            Text(status)
        }
    }
}
